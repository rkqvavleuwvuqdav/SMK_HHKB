# imahorribleperson
used lfk repo to copy pasta fixng pins into a footprint

added v2 json for key layout
